//lex_auth_012906912922468352259
//do not modify the above line

package stringassignment3;

public class Tester {

	public static String reverseEachWord(String str) {
		// Implement your code here and change the return value accordingly
		return null;
	}

	public static void main(String args[]) {
		String str = "all cows eat grass";
		System.out.println(reverseEachWord(str));
	}

}
