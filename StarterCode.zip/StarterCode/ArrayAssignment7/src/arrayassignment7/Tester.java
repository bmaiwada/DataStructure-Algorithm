//lex_auth_012907362013306880288
//do not modify the above line

package arrayassignment7;

public class Tester {
	
	public static String[] findPermutations(String str){
		//Implement your code here and change the return value accordingly
        return null;
    }
    
    public static void main(String args[]){
        String str = "abc";
        String permutations[] = findPermutations(str);
        for(String permutation: permutations){
            if (permutation!=null)
                System.out.println(permutation);
        }
    }

}
