//lex_auth_01287442591667814426
//do not modify the above line

package finalassignment1;

public class Circle {
	//Implement your code here
}
