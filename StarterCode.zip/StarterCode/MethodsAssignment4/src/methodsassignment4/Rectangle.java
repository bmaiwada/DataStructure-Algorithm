//lex_auth_012890553012772864110
//do not modify the above line

package methodsassignment4;

public class Rectangle {
	//Implement your code here
}
