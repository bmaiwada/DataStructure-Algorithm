//lex_auth_012880454683738112345
//do not modify the above line

package abstractexercise1;

public class Student {
	//Implement your code here
}
