//lex_auth_012908173091069952511
//do not modify the above line

package exceptionexercise1;

public class Validator {
    //Implement your code here
}
