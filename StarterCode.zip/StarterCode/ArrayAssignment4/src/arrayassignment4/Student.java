//lex_auth_012909127698530304533
//do not modify the above line

package arrayassignment4;

public class Student {
	//Implement your code here
}
