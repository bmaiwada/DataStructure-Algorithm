//lex_auth_012876937895051264284
//do not modify the above line

package regexassignment3;

public class Shipment {
	public boolean checkProductNameValidity(String productName) {
		//Implement your code here and change the return value accordingly
		return false;  
	}
	
	public boolean checkProductIdValidity(String productId) {
		//Implement your code here and change the return value accordingly
		return false;  
	}
	
	public boolean checkTrackerIdValidity(String trackerId) {
		//Implement your code here and change the return value accordingly
		return false;  
	}
}
