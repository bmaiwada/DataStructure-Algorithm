//lex_auth_012908251364786176516
//do not modify the above line

package staticexercise1;

public class Bill {
	 //Implement your code here
}
