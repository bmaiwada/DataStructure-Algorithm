//lex_auth_012907624695250944483
//do not modify the above line

package methodoverloadingassignment1;

public class Tester {

	public static void main(String[] args) {

		Bill bill = new Bill();

		double price = bill.findPrice(1001);
		if (price > 0)
			System.out.println("Price of the selected item is $" + price);
		else
			System.out.println("The Item Id is invalid");

		price = bill.findPrice("Reebok", "T-shirt", 34);
		if (price > 0)
			System.out.println("Price of the selected item is $" + price);
		else
			System.out.println("The values are not valid");
	}

}
