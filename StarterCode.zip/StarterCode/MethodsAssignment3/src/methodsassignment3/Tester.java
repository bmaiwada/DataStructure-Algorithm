//lex_auth_012890546057764864103
//do not modify the above line

package methodsassignment3;

public class Tester {
	
	public static void main(String args[]) {

		Calculator calculator = new Calculator();

		// Assign a value to the member variable num of Calculator class

		// Invoke the method sumOfDigits of Calculator class and display the output

	}
}
