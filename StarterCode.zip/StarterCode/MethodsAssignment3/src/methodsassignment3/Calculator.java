//lex_auth_012890546057764864103
//do not modify the above line

package methodsassignment3;

public class Calculator {
	//Implement your code here
}
