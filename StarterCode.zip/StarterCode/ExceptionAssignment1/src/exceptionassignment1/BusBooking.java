//lex_auth_012921592276475904109
//do not modify the above line

package exceptionassignment1;

public class BusBooking {
    //Implement your code here
}
