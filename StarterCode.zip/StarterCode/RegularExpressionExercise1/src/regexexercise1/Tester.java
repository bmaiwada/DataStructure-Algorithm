//lex_auth_012876934755098624282
//do not modify the above line

package regexexercise1;

public class Tester {
	 public static boolean checkNameValidity(String name) {
		//Implement your code here and change the return value accordingly
		 return false; 
	    }
	    
	    public static void main(String[] args) {
	        
	        //Change the value of name for testing your code with different names
	        String name = "roger federer";
	        System.out.println("The name is "+ (checkNameValidity(name) ? "valid!" : "invalid!"));      
	    }
}
