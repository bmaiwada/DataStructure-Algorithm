//lex_auth_012907389184704512299
//do not modify the above line

package recursionassignment5;

public class Tester {
	 	public static int countSubstring(String inputString, String substring, int count) {
	 		//Implement your code here and change the return value accordingly
	 		return 0; 
	    }
	   
	    public static void main(String args[]) {
	        int count = countSubstring("I felt happy because I saw the others were Happy and because I knew I should feel happy, but I was not really happy","happy", 0);
	        System.out.println(count);
	    }
}
