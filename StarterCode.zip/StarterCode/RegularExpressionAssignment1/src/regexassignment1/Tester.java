//lex_auth_012890616515682304161
//do not modify the above line

package regexassignment1;

public class Tester {
	 public static boolean checkPasswordValidity(String password) {
		//Implement your code here and change the return value accordingly
		 return false; 
	    }
	    
	    public static void main(String[] args) {
	        
	        //Change the value of password for testing your code with different passwords
	        String password = "P@$sW0rd";
	        System.out.println("The password is "+ (checkPasswordValidity(password) ? "valid!" : "invalid!"));
	    }
}
