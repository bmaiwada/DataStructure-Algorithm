//lex_auth_012907551251406848427
//do not modify the above line

package encapsulationassignment2;

public class MovieTicket {
	
	//Implement your code here 
}
