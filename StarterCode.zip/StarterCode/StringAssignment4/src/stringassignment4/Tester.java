//lex_auth_012906904764366848254
//do not modify the above line

package stringassignment4;

public class Tester {
	
	public static int findHighestOccurrence(String str){
		//Implement your code here and change the return value accordingly
		 return 0; 
	}
	
	public static void main(String args[]){
		String str = "success";
	    System.out.println(findHighestOccurrence(str));
	}
}
