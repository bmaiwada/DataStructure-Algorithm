//lex_auth_012908260248895488520
//do not modify the above line

package staticassignment2;

public class Participant {
	
	 //Implement your code here

}
