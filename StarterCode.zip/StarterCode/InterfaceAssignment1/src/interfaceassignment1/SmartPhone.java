//lex_auth_01292151837944217650
//do not modify the above line

package interfaceassignment1;

public class SmartPhone {
	//Implement your code here
}
