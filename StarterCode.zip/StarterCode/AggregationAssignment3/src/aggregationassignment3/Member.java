//lex_auth_012890622843117568163
//do not modify the above line

package aggregationassignment3;

public class Member {
	
	//Implement your code here 
	
	//Uncomment the below method after implementation before verifying 
    //DO NOT MODIFY THE METHOD
    /*
    public String toString(){
        return "Member\nmemberId: "+this.memberId+"\nname: "+this.name;
    }
    */

}
