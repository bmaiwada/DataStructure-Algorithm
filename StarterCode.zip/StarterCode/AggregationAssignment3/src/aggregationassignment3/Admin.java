//lex_auth_012890622843117568163
//do not modify the above line

package aggregationassignment3;

public class Admin {
	//Implement your code here
}
