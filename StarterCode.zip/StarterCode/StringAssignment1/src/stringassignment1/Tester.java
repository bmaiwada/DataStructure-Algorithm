//lex_auth_012907356798779392287
//do not modify the above line

package stringassignment1;

public class Tester {
	
	 public static String moveSpecialCharacters(String str){
		//Implement your code here and change the return value accordingly
		 return null; 
		}
		
		public static void main(String args[]){
		    String str = "He@#$llo!*&";
		    System.out.println(moveSpecialCharacters(str));
		}

}
