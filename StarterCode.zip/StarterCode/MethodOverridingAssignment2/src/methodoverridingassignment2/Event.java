//lex_auth_012908097284579328502
//do not modify the above line

package methodoverridingassignment2;

public class Event {
	//Implement your code here
}
