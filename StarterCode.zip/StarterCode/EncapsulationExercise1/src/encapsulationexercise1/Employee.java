//lex_auth_01287482707103744057
//do not modify the above line

package encapsulationexercise1;

public class Employee {
	
	String employeeId;
	String employeeName;
	int salary;
	int bonus;
	int jobLevel;

	public void calculateSalary() {
		if (this.jobLevel >= 4) {
			this.bonus = 100;
		} else {
			this.bonus = 50;
		}
		this.salary += this.bonus;
	}

}
