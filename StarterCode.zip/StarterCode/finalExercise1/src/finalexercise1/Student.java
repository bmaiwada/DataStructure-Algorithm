//lex_auth_01291666846849433675
//do not modify the above line

package finalexercise1;

public class Student {
	//Implement your code here
}
