//lex_auth_01292098291036979225
//do not modify the above line

package abstractassignment1;

public class CreditCardPayment {
    //Implement your code here
}
