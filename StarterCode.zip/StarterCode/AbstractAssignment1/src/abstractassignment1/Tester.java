//lex_auth_01292098291036979225
//do not modify the above line

package abstractassignment1;

public class Tester {
	 public static void main(String args[]){
		 DebitCardPayment debitCardPayment = new DebitCardPayment(101);
	        double billAmount=Math.round(debitCardPayment.payBill(500)*100)/100.0;
			System.out.println("Customer Id: " + debitCardPayment.getCustomerId());
			System.out.println("Payment Id: " + debitCardPayment.getPaymentId());
			System.out.println("Service tax percentage: " + debitCardPayment.getServiceTaxPercentage());
			System.out.println("Discount percentage: " + debitCardPayment.getDiscountPercentage());
			System.out.println("Total bill amount: " + billAmount);
			
			CreditCardPayment creditCardPayment = new CreditCardPayment(102);
	        billAmount=Math.round(creditCardPayment.payBill(1000)*100)/100.0;
			System.out.println("Customer Id: " + creditCardPayment.getCustomerId());
			System.out.println("Payment Id: " + creditCardPayment.getPaymentId());
			System.out.println("Service tax percentage: " + creditCardPayment.getServiceTaxPercentage());
			System.out.println("Total bill amount: " + billAmount);
	    }
}
