//lex_auth_012907414165159936311
//do not modify the above line

package recursionassignment2;

public class Tester {
	  public static double findHPSum(int num) {
		//Implement your code here and change the return value accordingly
		  return 0; 
	    }
	    
	    public static void main(String args[]) {
	        System.out.println(findHPSum(3));
	    }
}
