//lex_auth_012909125609562112532
//do not modify the above line

package arrayassignment3;

public class Tester {

	public static int[] findLeapYears(int year) {
		// Implement your code here and change the return value accordingly
		return null;
	}

	public static void main(String[] args) {
		int year = 2000;
		int[] leapYears;
		leapYears = findLeapYears(year);
		for (int index = 0; index < leapYears.length; index++) {
			System.out.println(leapYears[index]);
		}
	}
}
