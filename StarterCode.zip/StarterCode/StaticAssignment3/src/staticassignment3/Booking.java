//lex_auth_012908251670077440518
//do not modify the above line

package staticassignment3;

public class Booking {
	 //Implement your code here
}
