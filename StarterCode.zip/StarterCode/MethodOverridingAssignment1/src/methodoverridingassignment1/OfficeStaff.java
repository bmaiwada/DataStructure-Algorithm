//lex_auth_01292096468030259214
//do not modify the above line

package methodoverridingassignment1;

public class OfficeStaff {
	 //Implement your code here
}
