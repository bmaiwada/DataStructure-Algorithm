//lex_auth_01289054031901491298
//do not modify the above line

package methodsexercise1;

public class Calculator {
	//Implement your code here
}
