//lex_auth_01289054031901491298
//do not modify the above line

package methodsexercise1;

public class Tester {
	
	public static void main(String args[]) {
		Calculator calculator = new Calculator();
		// Invoke the method findAverage of the Calculator class and display the average
	}
}
