//lex_auth_0130008620764692481835
//do not modify the above line

package integratedassignment1;

public class PermanentEmployee {
	//Implement your code here
	
	//Uncomment the code given below after implementing the class
	//Do not modify the code given below
	/*@Override
	public String toString() {
		return "Employee Id: "+getEmployeeId()+", Employee Name: "+getEmployeeName()+", Basic Pay: "+getBasicPay()+", Salary Components: "+getSalaryComponents()+", Assets: "+getAssets();
	}*/
}