//lex_auth_0130008620764692481835
//do not modify the above line

package integratedassignment1;

public class Resources {
	//Implement your code here
}