//lex_auth_012875034541367296266
//do not modify the above line

package inheritanceexercise1;

public class Tester {
	
	public static void main(String[] args) {
        DigitalCamera camera = new DigitalCamera("Canon",100);
        System.out.println(camera.getBrand()+" "+camera.getCost()+" "+camera.getMemory());
    }

}
