//lex_auth_012875034541367296266
//do not modify the above line

package inheritanceexercise1;

public class Camera {
	
	private String brand;
	private double cost;

	public Camera() {
		this.brand = "Nikon";
	}
    
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
}
