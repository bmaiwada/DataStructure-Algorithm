//lex_auth_012908111868043264503
//do not modify the above line

package methodoverridingexercise1;

public class User {
	// Implement your code here
}
