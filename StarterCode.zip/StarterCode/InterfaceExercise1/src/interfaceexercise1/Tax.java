//lex_auth_01292154183292518461
//do not modify the above line

package interfaceexercise1;

public interface Tax {
    //Implement your code here
}
