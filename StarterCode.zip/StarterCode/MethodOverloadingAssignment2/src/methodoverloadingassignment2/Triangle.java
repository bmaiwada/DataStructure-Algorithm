//lex_auth_012877025318608896373
//do not modify the above line

package methodoverloadingassignment2;

public class Triangle {
	//Implement your code here

}
