//lex_auth_012877025318608896373
//do not modify the above line

package methodoverloadingassignment2;

public class Point {
	
	//Reuse the code of Method Overloading - Exercise 1 
    
    //Uncomment the below method after implementation before verifying 
    //DO NOT MODIFY THE METHOD
    /*
    public String toString(){
        return "Point\nxCoordinate: "+this.getxCoordinate()+"\nyCoordinate: "+this.getyCoordinate();
    }
    */

}
