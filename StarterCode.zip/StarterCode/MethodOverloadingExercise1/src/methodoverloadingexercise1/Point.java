//lex_auth_012877018630356992365
//do not modify the above line

package methodoverloadingexercise1;

public class Point {
    //Implement your code here
}
