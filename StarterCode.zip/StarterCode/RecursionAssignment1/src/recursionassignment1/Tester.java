//lex_auth_012907378628927488293
//do not modify the above line

package recursionassignment1;

public class Tester {
	  public static int findFibonacci(int n) {
		//Implement your code here and change the return value accordingly
		  return 0; 
	    }

	    public static void main(String args[]) {
	        int n = 0;
	        if(n!=0)
	            System.out.println(findFibonacci(n));
	        else
	            System.out.println("Please enter a valid value for n");
	    }
}
